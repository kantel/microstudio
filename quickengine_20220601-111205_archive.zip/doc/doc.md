# Quick Engine

Quick Engine is a simple scene rendering and physics engine for 2D games.

## Import Quick Engine in my project

1. Create your microStudio project
2. With your project opened, navigate to the Explore section and to Quick Engine
3. Select the source file "quickengine" and click "Import to my project"

## Initialization

Quick Engine must be initialized with a call to ```Quick.init()```. You can do
this in the main ```init``` function of your project:

```
init = function()
  Quick.init()
  // set more parameters here
end
```

There is a number of parameters you can use to customize the engine, by setting their
values like in this example:

```
Quick.gravity = 20
Quick.friction = 50
```

|Parameter|Description|
|-|-|
|gravity|The amount of gravity. Default is 9.8.|
|friction|The global air friction. Ranges from 0 to 100|
|contact_friction|The amount of friction occurring when 2 objects are in contact|
|ground|The position of the ground on the y axis. Falling objects will stop when hitting the ground. Default value is -100|


## Add objects (sprites)

You can add objects to the current scene by calling

```
myobj = Quick.addSprite(sprite,x,y,width,height)
```

Arguments :

|argument|description|
|-|-|
|sprite|the name of the sprite|
|x|the x coordinate, position of the object in the scene|
|y|the y coordinate, position of the object in the scene|
|width|the width of the object|
|height|the height of the object|

The function returns an object which can be used to modify the coordinates and properties of the object.
The properties are the following:

|property|description|
|-|-|
|x|the x coordinate of the object|
|y|the y coordinate of the object|
|vx|the velocity of the object along the horizontal axis|
|vy|the velocity of the object along the vertical axis|
|name|the name of the sprite to draw for this object|
|width|the width of the object|
|height|the height of the object|
|rotation|the rotation of the object (in degrees)|
|fall|1 if the object is affected by gravity, 0 otherwise|
|fixed|whether the object can move or is fixed|
|solid|whether the object collides with other objects|

## Add maps

You can add a map by calling:

```
mymap = Quick.addMap(name,x,y,width,height)
```

Arguments :

|argument|description|
|-|-|
|name|the name of the map|
|x|the x coordinate, position of the map in the scene|
|y|the y coordinate, position of the map in the scene|
|width|the width to use for the display of the map|
|height|the height to use for the display of the map|

The function returns an object which can be used to modify the coordinates and properties of the map.
The properties are the following:

|property|description|
|-|-|
|x|the x coordinate of the map|
|y|the y coordinate of the map|
|width|the width of the map|
|height|the height of the map
|solid|whether the map cells have physics or not|

The map object also comes with a set of functions:

|function|description|
|-|-|
|map.setHollow(name)|defines the cells with given sprite name to not be solid (no physics)|
|map.setSolid(name)|defines the cells with given sprite name to be solid (physics enabled)|
|extractSprites(name)|Removes all the cells with given sprite name from the map and recreates them as individual objects inserted in the scene. The function returns a list of the created objects.|

## Update

In order for the physics engine to do its job, you need to call ```Quick.update()``` in the
body of your main ```update``` function:

```
update = function()
  Quick.update()
end
```

## Draw

The scene is drawn with a simple call to ```Quick.draw()```. Most of the time, your 
main draw function thus looks like this:

```
draw = function()
  Quick.draw()
end
```


## Collisions

### object / object collision

Test whether an object collides with another object:

```
  Quick.spriteCollision(object1,object2)
```

Returns 1 if the objects collide, 0 otherwise.

### Testing map cells

You can test the map cell present at any point of the screen space, with:

```
  Quick.mapCellAt(map,x,y)
```

The values of x and y are screen coordinates. The function returns the name of the sprite found at this
particular location of the map, or 0 if the map grid is empty at this location.
