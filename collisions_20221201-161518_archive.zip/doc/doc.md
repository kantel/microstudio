# Collisions

This library introduces a set of functions to detect hits, collisions, sprites and map
tiles at any given point in screen coordinates, sprite collisions by sprite names.

## hit

Returns 1 (true) if a given point is hitting a given shape or a sprite:
```
  hit( x, y, obj_x, obj_y, obj_w, obj_h )
```

|argument|description|
|-|-|
|x|the x coordinate of the point to test e.g. `mouse.x`|
|y|the y coordinate of the point to test e.g. `mouse.y`|
|obj_x|the x coordinate where the shape or sprite was drawn|
|obj_y|the y coordinate where the shape or sprite was drawn|
|obj_w|the width of the shape or sprite|
|obj_h|the height of the shape or sprite|

|Return value|
|-|
|`1` if the point is inside the shape, else `0`|

## collision

Returns 1 (true) whenever two shapes or sprites overlap:
```
  collision(x1,y1,w1,h1,x2,y2,w2,h2)
```
|argument|description|
|-|-|
|x1|the x coordinate of the first shape / sprite|
|y1|the y coordinate of the first shape / sprite|
|w1|the width of the first shape / sprite|
|h1|the height of the first shape / sprite|
|x2|the x coordinate of the second shape / sprite|
|y2|the y coordinate of the second shape / sprite|
|w2|the width of the second shape / sprite|
|h2|the height of the second shape / sprite|

|Return value|
|-|
|`1` if the shapes overlap, else `0`|

## Map Hit

Using this function doesn't require any specific setup. All you have to do is draw
your map on screen normally using `screen.drawMap`.

Returns the name of the map tile drawn at coordinates x and y:

```
  mapHit( x, y, map )
```
|argument|description|
|-|-|
|x|the x coordinate of the point to check|
|y|the y coordinate of the point to check|
|map|the map name (or map object) to check|

|Return value|
|-|
|`0` if nothing is hit, or the name of the sprite tile being hit|

## Sprite hit and collisions

These sprite functions do not require any specific setup. They will remember where
your sprites were drawn when you used `screen.drawSprite`.

### spriteHit()

Can be used to check if a given point hits a given sprite, and where:
```
  spriteHit( x, y, sprite_name )
```

|argument|description|
|-|-|
|x|the x coordinate of the point to test e.g. `mouse.x`|
|y|the y coordinate of the point to test e.g. `mouse.y`|
|sprite_name|the name of a sprite|

|Return value|
|-|
|`0` if the point doesn't hit any sprite of that name ; or an object with the sprite position (x, y, w, h) if hit|

### spriteCollision()

Finds a collision between two sprites (by name), if any:
```
  spriteCollision( sprite_name_1, sprite_name_2 )
```

|argument|description|
|-|-|
|sprite_name_1|the name of a sprite|
|sprite_name_2|the name of another sprite|

|Return value|
|-|
|`0` if there is no collision found. If a collision is found, returns a list of 2 objects with x, y, w, h coordinates of the 2 first colliding sprites found|


### spriteCollisionList()

Returns a list of collisions between 2 sprite names. Can be used to detect many simultaneous collisions
between bullets and enemies for example.
```
  spriteCollisionList( sprite_name_1, sprite_name_2 )
```

|argument|description|
|-|-|
|sprite_name_1|the name of a sprite|
|sprite_name_2|the name of another sprite|

|Return value|
|-|
|A list of collisions found ; empty if no collision, or for each collision found, a list of 2 object positions (see `spriteCollision()`)|

